import java.util.Queue;
import java.util.LinkedList;

class Queues{
	public static void main(String args[]){
		Queue<String> queue = new LinkedList<String>();
		
		queue.offer("Karan");
		queue.offer("Chad");
		queue.offer("Steve");
		queue.offer("Harold");
		
		System.out.println(queue);
		
		queue.poll();
		
		System.out.println(queue);
		
		queue.offer("Hello");
		
		System.out.println(queue);
		
		LinkedList<String> linkedlist = new
		
		
	}
}