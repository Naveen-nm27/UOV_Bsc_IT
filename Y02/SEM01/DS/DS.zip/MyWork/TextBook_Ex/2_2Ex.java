import java.util.*;

class Demo{
	public static void main(String args[]){
		ArrayList<String> me = new ArrayList<String>();
		List<String> you =  new ArrayList<>();
		ArrayList<Integer> them = new ArrayList<String>();
		var we = new ArrayList<String>();
		List<String> you2; you2 = new ArrayList<String>(); 
	}
}