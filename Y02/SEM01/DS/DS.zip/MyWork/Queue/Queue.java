class QueueDemo {
	int size;
	int tail = -1;
	int head = -1;
	Object[] queue;
	
	
	QueueDemo(int size){
		queue = [size];
		size = -1;
		
	}
	
	public void add(){
		
	}
}